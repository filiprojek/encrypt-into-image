Encrypt images into another images bash script v1.0

1) Encrypting
     - Insert pictures into "encrypt/toencrypt" folder
     - Insert cover pictures into "encrypt/toencrypt/coverimages" folder
     - Run the script "encrypt.sh" and follow the instructions
     - Encrypted images will be in the "encrypt/encrypted" folder
2) Decrypting
    - Insert pictures into "decrypt/todecrypt" folder
    - Run the script "decrypt.sh" and follow the instructions
    - Decrypted pictures can be found in "decrypt/decrypted"



Used software - steghide version 0.5.1
This script was created by Filip Rojek in 4/2020

